VERSION = (1, 2, 3)

__version__ = '.'.join(map(str, VERSION))